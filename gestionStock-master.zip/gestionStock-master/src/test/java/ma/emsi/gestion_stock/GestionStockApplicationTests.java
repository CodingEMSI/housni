package ma.emsi.gestion_stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionStockApplicationTests {

    @Test
    void contextLoads() {
    }

}
